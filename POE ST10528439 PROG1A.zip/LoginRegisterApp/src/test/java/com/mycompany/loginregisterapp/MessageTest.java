/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.loginregisterapp;

import java.io.File;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class MessageTest {
    
     // Test data from the PoE
    private static final String RECIPIENT_1 = "+27718693002";
    private static final String TEXT_1 = "Hi Mike, can you join us for dinner tonight?";
    private static final String RECIPIENT_2 = "08575975889";
    private static final String TEXT_2 = "Hi Keegan, did you receive the payment?";

    @BeforeEach
    public void setUp() {
        Message.resetMessages();
        new File(Message.JSON_FILE).delete();
    }

    @AfterEach
    public void tearDown() {
        new File(Message.JSON_FILE).delete();
    }

    // ----- Message length -----
    @Test
    public void testMessageLengthSuccess() {
        Message message = new Message(0, RECIPIENT_1, TEXT_1);
        assertEquals("Message ready to send.", message.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        String longText = "a".repeat(260); // 10 characters too long
        Message message = new Message(0, RECIPIENT_1, longText);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                message.checkMessageLength());
    }

    // ----- Recipient number -----
    @Test
    public void testRecipientCorrectlyFormatted() {
        Message message = new Message(0, RECIPIENT_1, TEXT_1);
        assertEquals("Cell phone number successfully captured.", message.checkRecipientCell());
    }

    @Test
    public void testRecipientIncorrectlyFormatted() {
        Message message = new Message(1, RECIPIENT_2, TEXT_2);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                message.checkRecipientCell());
    }

    // ----- Message hash -----
    @Test
    public void testMessageHashTestCase1() {
        // ID starting with "00" so the expected hash matches the PoE: 00:0:HITONIGHT
        Message message = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        assertEquals("00:0:HITONIGHT", message.createMessageHash());
    }

    @Test
    public void testMessageHashesInLoop() {
        String[] ids = {"0012345678", "4598765432"};
        String[] recipients = {RECIPIENT_1, RECIPIENT_2};
        String[] texts = {TEXT_1, TEXT_2};
        String[] expected = {"00:0:HITONIGHT", "45:1:HIPAYMENT"};

        for (int i = 0; i < texts.length; i++) {
            Message message = new Message(ids[i], i, recipients[i], texts[i]);
            assertEquals(expected[i], message.createMessageHash());
        }
    }

    // ----- Message ID -----
    @Test
    public void testMessageIDCreated() {
        Message message = new Message(0, RECIPIENT_1, TEXT_1);
        assertTrue(message.checkMessageID());
        assertEquals(10, message.getMessageID().length());
        assertEquals("Message ID generated: " + message.getMessageID(), message.displayMessageID());
    }

    @Test
    public void testMessageIDTooLong() {
        Message message = new Message("12345678901", 0, RECIPIENT_1, TEXT_1);
        assertFalse(message.checkMessageID());
    }

    // ----- Send / Disregard / Store -----
    @Test
    public void testSendMessage() {
        Message message = new Message(0, RECIPIENT_1, TEXT_1);
        assertEquals("Message successfully sent.", message.sentMessage(1));
    }

    @Test
    public void testDisregardMessage() {
        Message message = new Message(1, RECIPIENT_2, TEXT_2);
        assertEquals("Press 0 to delete the message.", message.sentMessage(2));
    }

    @Test
    public void testStoreMessage() {
        Message message = new Message(0, RECIPIENT_1, TEXT_1);
        assertEquals("Message successfully stored.", message.sentMessage(3));
        assertTrue(new File(Message.JSON_FILE).exists());
    }

    // ----- Total messages sent -----
    @Test
    public void testReturnTotalMessages() {
        // Message 1 is sent, message 2 is discarded -> total sent is 1
        new Message(0, RECIPIENT_1, TEXT_1).sentMessage(1);
        new Message(1, RECIPIENT_2, TEXT_2).sentMessage(2);
        assertEquals(1, Message.returnTotalMessages());
    }

    @Test
    public void testPrintMessages() {
        Message message = new Message("0012345678", 0, RECIPIENT_1, TEXT_1);
        message.sentMessage(1);
        assertTrue(Message.printMessages().contains("00:0:HITONIGHT"));
    }
}
