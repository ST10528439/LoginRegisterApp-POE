/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

 package com.mycompany.loginregisterapp;

import java.io.File;
import org.json.JSONArray;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Part 3 unit tests - uses the PoE test data for messages 1 to 5.
 *
 * @author Student
 */
public class MessageManagerTest {

    private static final String MSG_1 = "Did you get the cake?";
    private static final String MSG_2 = "Where are you? You are late! I have asked you to be on time.";
    private static final String MSG_3 = "Yohoooo, I am at your gate.";
    private static final String MSG_4 = "It is dinner time!";
    private static final String MSG_5 = "Ok, I am leaving without you.";

    private MessageManager manager;
    private Message message2;

    /** Sends/stores/disregards a message the same way the app does, then adds it to the arrays. */
    private Message addTestMessage(String id, int number, String recipient, String text, int choice) {
        Message message = new Message(id, number, recipient, text);
        message.sentMessage(choice);                 // 1 = send, 2 = disregard, 3 = store (writes JSON)
        manager.addMessage(message, MessageManager.flagForChoice(choice));
        return message;
    }

    @BeforeEach
    public void setUp() {
        Message.resetMessages();
        new File(Message.JSON_FILE).delete();
        manager = new MessageManager();

        addTestMessage("1234567890", 0, "+27834557896", MSG_1, 1);            // Sent
        message2 = addTestMessage("2234567890", 1, "+27838884567", MSG_2, 3); // Stored
        addTestMessage("3234567890", 2, "+27834484567", MSG_3, 2);            // Disregard
        addTestMessage("0838884567", 3, "0838884567", MSG_4, 1);              // Sent (developer entry)
        addTestMessage("5234567890", 4, "+27838884567", MSG_5, 3);            // Stored
    }

    @AfterEach
    public void tearDown() {
        new File(Message.JSON_FILE).delete();
    }

    // ----- assertEquals tests from the PoE -----
    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        assertArrayEquals(new String[]{MSG_1, MSG_4}, manager.getSentMessages());
    }

    @Test
    public void testDisplayLongestMessage() {
        assertEquals(MSG_2, manager.getLongestStoredMessage());
    }

    @Test
    public void testSearchForMessageID() {
        assertEquals(MSG_4, manager.searchMessageByID("0838884567"));
    }

    @Test
    public void testSearchMessagesForRecipient() {
        assertArrayEquals(new String[]{MSG_2, MSG_5}, manager.searchByRecipient("+27838884567"));
    }

    @Test
    public void testDeleteMessageUsingHash() {
        assertEquals("Message: \"" + MSG_2 + "\" successfully deleted.",
                manager.deleteByHash(message2.getMessageHash()));
        assertArrayEquals(new String[]{MSG_5}, manager.getStoredMessages());
        // the JSON file is updated as well
        assertEquals(1, Message.readJsonArray(Message.JSON_FILE).length());
    }

    @Test
    public void testDisplayReport() {
        String report = manager.displaySentReport();
        String[] expectedHashes = {"12:0:DIDCAKE", "08:3:ITTIME"};
        String[] expectedRecipients = {"+27834557896", "0838884567"};
        String[] expectedMessages = {MSG_1, MSG_4};
        for (int i = 0; i < expectedHashes.length; i++) {
            assertTrue(report.contains("Message Hash: " + expectedHashes[i]));
            assertTrue(report.contains("Recipient: " + expectedRecipients[i]));
            assertTrue(report.contains("Message: " + expectedMessages[i]));
        }
    }

    // ----- Extra tests for the other arrays and features -----
    @Test
    public void testStoredMessagesReadFromJsonFile() {
        JSONArray json = Message.readJsonArray(Message.JSON_FILE);
        assertEquals(2, json.length());

        MessageManager freshManager = new MessageManager(); // e.g. the app restarted
        assertEquals(2, freshManager.loadStoredMessages());
        assertArrayEquals(new String[]{MSG_2, MSG_5}, freshManager.getStoredMessages());
    }

    @Test
    public void testDisregardedMessagesArray() {
        assertArrayEquals(new String[]{MSG_3}, manager.getDisregardedMessages());
    }

    @Test
    public void testMessageHashAndIDArrays() {
        assertEquals(5, manager.getMessageHashes().length);
        assertArrayEquals(new String[]{"1234567890", "2234567890", "3234567890", "0838884567", "5234567890"},
                manager.getMessageIDs());
        assertEquals("22:1:WHERETIME", manager.getMessageHashes()[1]);
    }

    @Test
    public void testDisplayMessageByID() {
        assertEquals("Recipient: +27838884567\nMessage: " + MSG_5, manager.displayMessageByID("5234567890"));
    }

    @Test
    public void testStoredReportAndSenderRecipient() {
        String report = manager.displayStoredReport();
        assertTrue(report.contains(MSG_2) && report.contains(MSG_5));
        assertTrue(manager.displayStoredSenderAndRecipient("Kyle Smith").contains("Recipient: +27838884567"));
    }

    @Test
    public void testNotFoundCases() {
        assertEquals("Message ID not found.", manager.searchMessageByID("9999999999"));
        assertEquals("Message hash not found.", manager.deleteByHash("99:9:NOTHERE"));
        assertEquals(0, manager.searchByRecipient("+27000000000").length);
    }
}