/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.loginregisterapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
    private final Login login = new Login("Kyle", "Smith");

    // ----- assertEquals tests -----
    @Test
    public void testUsernameCorrectlyFormatted() {
        assertEquals("Username successfully captured.", login.getUsernameMessage("kyl_1"));
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        assertEquals(Login.USERNAME_BAD, login.getUsernameMessage("kyle!!!!!!!"));
    }

    @Test
    public void testPasswordMeetsComplexity() {
        assertEquals("Password successfully captured.", login.getPasswordMessage("Ch&&sec@ke99!"));
    }

    @Test
    public void testPasswordDoesNotMeetComplexity() {
        assertEquals(Login.PASSWORD_BAD, login.getPasswordMessage("password"));
    }

    @Test
    public void testCellCorrectlyFormatted() {
        assertEquals("Cell number successfully captured.", login.getCellPhoneMessage("+27838968976"));
    }

    @Test
    public void testCellIncorrectlyFormatted() {
        assertEquals("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.",
                login.getCellPhoneMessage("08966553"));
    }

   

    @Test
    public void testLoginStatusMessage() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        boolean loggedIn = login.loginUser("kyl_1", "Ch&&sec@ke99!");
        assertEquals("Welcome Kyle, Smith it is great to see you.", login.returnLoginStatus(loggedIn));
    }

    // ----- assertTrue / assertFalse tests -----
    @Test
    public void testLoginSuccessful() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFailed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(login.loginUser("kyl_1", "wrongPassword1!"));
    }

    @Test
    public void testUsernameTrue() { assertTrue(login.checkUserName("kyl_1")); }

    @Test
    public void testUsernameFalse() { assertFalse(login.checkUserName("kyle!!!!!!!")); }

    @Test
    public void testPasswordTrue() { assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!")); }

    @Test
    public void testPasswordFalse() { assertFalse(login.checkPasswordComplexity("password")); }

    @Test
    public void testCellTrue() { assertTrue(login.checkCellPhoneNumber("+27838968976")); }

    @Test
    public void testCellFalse() { assertFalse(login.checkCellPhoneNumber("08966553")); }

}