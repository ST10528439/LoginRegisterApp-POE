/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginregisterapp;

import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Part 3 - keeps every message in arrays and provides the "Stored Messages" features.
 *
 * Parallel arrays: index i in messageIDs, messageHashes, recipients, messageTexts and flags
 * all describe the SAME message.
 *
 * Category arrays: sentMessages and disregardedMessages hold the text of those messages.
 * The stored arrays (storedMessages, storedRecipients, storedIDs, storedHashes) are filled
 * by reading messages.json back in (see loadStoredMessages()).
 *
 * @author Student
 */
public class MessageManager {

    public static final int MAX_MESSAGES = 100;

    public static final String FLAG_SENT = "Sent";
    public static final String FLAG_STORED = "Stored";
    public static final String FLAG_DISREGARD = "Disregard";

    // ----- Parallel arrays: all messages -----
    private final String[] messageIDs = new String[MAX_MESSAGES];
    private final String[] messageHashes = new String[MAX_MESSAGES];
    private final String[] recipients = new String[MAX_MESSAGES];
    private final String[] messageTexts = new String[MAX_MESSAGES];
    private final String[] flags = new String[MAX_MESSAGES];
    private int messageCount = 0;

    // ----- Sent and disregarded messages -----
    private final String[] sentMessages = new String[MAX_MESSAGES];
    private int sentCount = 0;
    private final String[] disregardedMessages = new String[MAX_MESSAGES];
    private int disregardedCount = 0;

    // ----- Stored messages (read from the JSON file) -----
    private final String[] storedMessages = new String[MAX_MESSAGES];
    private final String[] storedRecipients = new String[MAX_MESSAGES];
    private final String[] storedIDs = new String[MAX_MESSAGES];
    private final String[] storedHashes = new String[MAX_MESSAGES];
    private int storedCount = 0;

    /** Turns the menu choice (1, 2, 3) into a flag.
     * @param choice 1 = Send, 2 = Disregard, 3 = Store
     * @return the matching flag */
    public static String flagForChoice(int choice) {
        switch (choice) {
            case 1: return FLAG_SENT;
            case 2: return FLAG_DISREGARD;
            default: return FLAG_STORED;
        }
    }

    /**
     * Adds a message to the arrays.
     * Stored messages are already saved to JSON by Message.storeMessage(), so for those
     * the stored arrays are refreshed by reading the JSON file again.
     * @param message the message
     * @param flag Sent, Stored or Disregard
     * @return false if the arrays are full
     */
    public boolean addMessage(Message message, String flag) {
        if (messageCount >= MAX_MESSAGES) {
            return false;
        }
        addToParallelArrays(message.getMessageID(), message.getMessageHash(),
                message.getRecipient(), message.getMessageText(), flag);

        if (flag.equals(FLAG_SENT)) {
            sentMessages[sentCount++] = message.getMessageText();
        } else if (flag.equals(FLAG_DISREGARD)) {
            disregardedMessages[disregardedCount++] = message.getMessageText();
        } else {
            loadStoredMessages();
        }
        return true;
    }

    private void addToParallelArrays(String id, String hash, String recipient, String text, String flag) {
        messageIDs[messageCount] = id;
        messageHashes[messageCount] = hash;
        recipients[messageCount] = recipient;
        messageTexts[messageCount] = text;
        flags[messageCount] = flag;
        messageCount++;
    }

    /**
     * Reads messages.json into the stored-message arrays.
     * Stored messages from an earlier run that are not in the parallel arrays yet are
     * added too, so they can also be searched and deleted.
     *
     * Code attribution:
     * Reading a JSON array and looping through its objects with getJSONObject(i) / getString(key)
     * is adapted from:
     *   Leary, S. (2025) JSON-java. GitHub. Available at: https://github.com/stleary/JSON-java
     *   Baeldung (2024) Introduction to JSON-Java. Available at: https://www.baeldung.com/java-org-json
     * @return the number of stored messages read
     */
    public int loadStoredMessages() {
        JSONArray jsonArray = Message.readJsonArray(Message.JSON_FILE);
        storedCount = 0;

        for (int i = 0; i < jsonArray.length() && storedCount < MAX_MESSAGES; i++) {
            JSONObject json = jsonArray.getJSONObject(i);
            String id = json.getString("messageID");
            String hash = json.getString("messageHash");
            String recipient = json.getString("recipient");
            String text = json.getString("message");

            storedIDs[storedCount] = id;
            storedHashes[storedCount] = hash;
            storedRecipients[storedCount] = recipient;
            storedMessages[storedCount] = text;
            storedCount++;

            if (indexOfID(id) == -1 && messageCount < MAX_MESSAGES) {
                addToParallelArrays(id, hash, recipient, text, FLAG_STORED);
            }
        }
        return storedCount;
    }

    /** Writes the current stored arrays back to messages.json (used after a delete). */
    private void saveStoredMessages() {
        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < storedCount; i++) {
            JSONObject json = new JSONObject();
            json.put("messageID", storedIDs[i]);
            json.put("messageHash", storedHashes[i]);
            json.put("recipient", storedRecipients[i]);
            json.put("message", storedMessages[i]);
            jsonArray.put(json);
        }
        Message.writeJsonArray(Message.JSON_FILE, jsonArray);
    }

    // =====================================================================
    // a) Sender and recipient of all stored messages
    // =====================================================================
    /** @param sender the logged-in user
     * @return one line per stored message */
    public String displayStoredSenderAndRecipient(String sender) {
        if (storedCount == 0) {
            return "There are no stored messages.";
        }
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < storedCount; i++) {
            output.append(i + 1).append(") Sender: ").append(sender)
                  .append(" | Recipient: ").append(storedRecipients[i]).append("\n");
        }
        return output.toString().trim();
    }

    // =====================================================================
    // b) Longest stored message
    // =====================================================================
    /** @return the longest stored message */
    public String getLongestStoredMessage() {
        if (storedCount == 0) {
            return "There are no stored messages.";
        }
        String longest = storedMessages[0];
        for (int i = 1; i < storedCount; i++) {
            if (storedMessages[i].length() > longest.length()) {
                longest = storedMessages[i];
            }
        }
        return longest;
    }

    // =====================================================================
    // c) Search by message ID
    // =====================================================================
    private int indexOfID(String id) {
        for (int i = 0; i < messageCount; i++) {
            if (messageIDs[i].equals(id)) {
                return i;
            }
        }
        return -1;
    }

    /** @param id the message ID to find
     * @return the message text, or a not-found message */
    public String searchMessageByID(String id) {
        int index = indexOfID(id);
        return index == -1 ? "Message ID not found." : messageTexts[index];
    }

    /** @param id the message ID to find
     * @return the recipient and message for display */
    public String displayMessageByID(String id) {
        int index = indexOfID(id);
        if (index == -1) {
            return "Message ID not found.";
        }
        return "Recipient: " + recipients[index] + "\nMessage: " + messageTexts[index];
    }

    // =====================================================================
    // d) All messages sent or stored for a recipient
    // =====================================================================
    /** @param recipient the cell number to search for
     * @return every sent or stored message for that recipient */
    public String[] searchByRecipient(String recipient) {
        String[] found = new String[messageCount];
        int foundCount = 0;
        for (int i = 0; i < messageCount; i++) {
            if (recipients[i].equals(recipient) && !flags[i].equals(FLAG_DISREGARD)) {
                found[foundCount++] = messageTexts[i];
            }
        }
        return Arrays.copyOf(found, foundCount);
    }

    // =====================================================================
    // e) Delete using the message hash
    // =====================================================================
    /** @param hash the message hash
     * @return confirmation, or a not-found message */
    public String deleteByHash(String hash) {
        int index = -1;
        for (int i = 0; i < messageCount; i++) {
            if (messageHashes[i].equalsIgnoreCase(hash)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            return "Message hash not found.";
        }

        String text = messageTexts[index];
        String flag = flags[index];

        // Remove from the parallel arrays
        removeAt(messageIDs, index, messageCount);
        removeAt(messageHashes, index, messageCount);
        removeAt(recipients, index, messageCount);
        removeAt(messageTexts, index, messageCount);
        removeAt(flags, index, messageCount);
        messageCount--;

        // Remove from the category array it belongs to
        if (flag.equals(FLAG_SENT)) {
            sentCount = removeValue(sentMessages, text, sentCount);
        } else if (flag.equals(FLAG_DISREGARD)) {
            disregardedCount = removeValue(disregardedMessages, text, disregardedCount);
        } else {
            for (int i = 0; i < storedCount; i++) {
                if (storedHashes[i].equalsIgnoreCase(hash)) {
                    removeAt(storedIDs, i, storedCount);
                    removeAt(storedHashes, i, storedCount);
                    removeAt(storedRecipients, i, storedCount);
                    removeAt(storedMessages, i, storedCount);
                    storedCount--;
                    break;
                }
            }
            saveStoredMessages(); // keep the JSON file in step with the array
        }
        return "Message: \"" + text + "\" successfully deleted.";
    }

    /** Shifts every element after index one place left and clears the last slot. */
    private static void removeAt(String[] array, int index, int count) {
        for (int i = index; i < count - 1; i++) {
            array[i] = array[i + 1];
        }
        array[count - 1] = null;
    }

    /** Removes the first element equal to value; returns the new count. */
    private static int removeValue(String[] array, String value, int count) {
        for (int i = 0; i < count; i++) {
            if (array[i].equals(value)) {
                removeAt(array, i, count);
                return count - 1;
            }
        }
        return count;
    }

    // =====================================================================
    // f) Reports
    // =====================================================================
    private static String reportEntry(String id, String hash, String recipient, String text) {
        return "Message ID: " + id
                + "\nMessage Hash: " + hash
                + "\nRecipient: " + recipient
                + "\nMessage: " + text
                + "\n----------------------\n";
    }

    /** @return full details of every stored message */
    public String displayStoredReport() {
        if (storedCount == 0) {
            return "There are no stored messages.";
        }
        StringBuilder report = new StringBuilder("===== Stored Messages Report =====\n");
        for (int i = 0; i < storedCount; i++) {
            report.append(reportEntry(storedIDs[i], storedHashes[i], storedRecipients[i], storedMessages[i]));
        }
        return report.toString();
    }

    /** @return full details of every sent message */
    public String displaySentReport() {
        StringBuilder report = new StringBuilder("===== Sent Messages Report =====\n");
        int found = 0;
        for (int i = 0; i < messageCount; i++) {
            if (flags[i].equals(FLAG_SENT)) {
                report.append(reportEntry(messageIDs[i], messageHashes[i], recipients[i], messageTexts[i]));
                found++;
            }
        }
        return found == 0 ? "No messages have been sent." : report.toString();
    }

    // ----- Getters (return copies trimmed to the number of items) -----
    public String[] getSentMessages() { return Arrays.copyOf(sentMessages, sentCount); }
    public String[] getDisregardedMessages() { return Arrays.copyOf(disregardedMessages, disregardedCount); }
    public String[] getStoredMessages() { return Arrays.copyOf(storedMessages, storedCount); }
    public String[] getMessageHashes() { return Arrays.copyOf(messageHashes, messageCount); }
    public String[] getMessageIDs() { return Arrays.copyOf(messageIDs, messageCount); }
}