/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginregisterapp;

/**
 *
 * @author Student
 */
public class Login {
     public static final String USERNAME_OK = "Username successfully captured.";
    public static final String USERNAME_BAD = "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";

    public static final String PASSWORD_OK = "Password successfully captured.";
    public static final String PASSWORD_BAD = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";

    public static final String CELL_OK = "Cell number successfully captured.";
    public static final String CELL_BAD = "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";

    public static final String REGISTER_CELL_BAD = "Cell phone number incorrectly formatted or does not contain international code.";
    public static final String REGISTER_OK = "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";

    public static final String LOGIN_BAD = "Username or password incorrect, please try again.";

    /*
     * Cell phone regex: "+27" (South African international code) followed by 9 digits.
     * Code attribution:
     *   Oracle (2024) Class Pattern (Java SE Documentation). Available at:
     *   https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/regex/Pattern.html
     *   regex101 (2024) Online regex tester and debugger. Available at: https://regex101.com/
     */
    private static final String CELL_REGEX = "^\\+27[0-9]{9}$";

    
    private String registeredUsername;
    private String registeredPassword;
    private String firstName;
    private String lastName;

    public Login() {}

    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

       
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }

        return hasCapital && hasDigit && hasSpecial;
    }

   
    public boolean checkCellPhoneNumber(String cellNumber) {
        return cellNumber != null && cellNumber.matches(CELL_REGEX);
    }

    

    public String getUsernameMessage(String username) {
        return checkUserName(username) ? USERNAME_OK : USERNAME_BAD;
    }

    public String getPasswordMessage(String password) {
        return checkPasswordComplexity(password) ? PASSWORD_OK : PASSWORD_BAD;
    }

    public String getCellPhoneMessage(String cellNumber) {
        return checkCellPhoneNumber(cellNumber) ? CELL_OK : CELL_BAD;
    }

   

    /** Registers the user if every detail is valid; otherwise returns the first error message.
     * @param username
     * @param password
     * @param cellNumber
     * @return  */
    public String registerUser(String username, String password, String cellNumber) {
        if (!checkUserName(username)) {
            return USERNAME_BAD;
        }
        if (!checkPasswordComplexity(password)) {
            return PASSWORD_BAD;
        }
        if (!checkCellPhoneNumber(cellNumber)) {
            return REGISTER_CELL_BAD;
        }

        this.registeredUsername = username;
        this.registeredPassword = password;
        return REGISTER_OK;
    }

    /** True only if the details match what was stored at registration.
     * @param username
     * @param password
     * @return  */
    public boolean loginUser(String username, String password) {
        return username != null && password != null
                && username.equals(registeredUsername)
                && password.equals(registeredPassword);
    }

    
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you.";
        }
        return LOGIN_BAD;
    }

    public void setFirstName(String firstName) { this.firstName = firstName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

}