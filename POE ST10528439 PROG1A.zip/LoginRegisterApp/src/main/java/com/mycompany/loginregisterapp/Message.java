/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginregisterapp;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author ST10528439
 */

public class Message {

    // ----- Messages the system returns (kept as constants so tests use the same text) -----
    public static final String MESSAGE_READY = "Message ready to send.";
    public static final String RECIPIENT_OK = "Cell phone number successfully captured.";
    public static final String RECIPIENT_BAD = "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    public static final String SENT = "Message successfully sent.";
    public static final String DISREGARD = "Press 0 to delete the message.";
    public static final String STORED = "Message successfully stored.";
    public static final String INVALID_OPTION = "Invalid option, please choose 1, 2 or 3.";

    public static final int MAX_LENGTH = 250;
    public static final String JSON_FILE = "messages.json";

    // ----- Shared by ALL messages (static) -----
    private static int totalMessagesSent = 0;
    private static final List<String> sentMessages = new ArrayList<>();

    // ----- Details of THIS message -----
    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;
    private final String messageHash;

    /** Normal constructor: the message ID is generated randomly.
     * @param messageNumber
     * @param recipient
     * @param messageText */
    public Message(int messageNumber, String recipient, String messageText) {
        this(generateMessageID(), messageNumber, recipient, messageText);
    }

    /** Constructor with a known ID - used by the unit tests so the hash is predictable.
     * @param messageID
     * @param messageNumber
     * @param recipient
     * @param messageText */
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    /**
     * Builds a random ten-digit message ID using string manipulation.
     * A random number is turned into text, padded on the left with zeros so it is
     * never shorter than ten digits, and then substring() keeps the last ten digits.
     * @return a ten-digit message ID
     */
    public static String generateMessageID() {
        Random random = new Random();
        // "& Long.MAX_VALUE" removes the minus sign so we only get digits
        String randomDigits = String.valueOf(random.nextLong() & Long.MAX_VALUE);
        String padded = "0000000000" + randomDigits;
        return padded.substring(padded.length() - 10);
    }

    /** True if the message ID is not more than ten characters.
     * @return  */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    /** Message shown when the ID has been created.
     * @return  */
    public String displayMessageID() {
        return "Message ID generated: " + messageID;
    }

    /** Reuses the Part 1 cell phone check from Login2 (international code, correct length).
     * @return  */
    public String checkRecipientCell() {
        Login checker = new Login();
        if (checker.checkCellPhoneNumber(recipient)) {
            return RECIPIENT_OK;
        }
        return RECIPIENT_BAD;
    }

    /** Checks that the message is 250 characters or less.
     * @return  */
    public String checkMessageLength() {
        if (messageText.length() <= MAX_LENGTH) {
            return MESSAGE_READY;
        }
        int extra = messageText.length() - MAX_LENGTH;
        return "Message exceeds 250 characters by " + extra + "; please reduce the size.";
    }

    /**
     * Hash = first two digits of the ID : message number : first word + last word, in capitals.
     * Example: 00:0:HITONIGHT
     * @return 
     */
    public final String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);

        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        // Remove punctuation such as , ? ! so "tonight?" becomes "tonight"
        firstWord = firstWord.replaceAll("[^a-zA-Z0-9]", "");
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");

        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    /**
     * Acts on the user's choice: 1 = Send, 2 = Disregard, 3 = Store.
     * Returns the message to show the user.
     * @param choice
     * @return 
     */
    public String sentMessage(int choice) {
        switch (choice) {
            case 1 -> {
                totalMessagesSent++;
                sentMessages.add(getMessageDetails());
                return SENT;
            }
            case 2 -> {
                return DISREGARD;
            }
            case 3 -> {
                storeMessage();
                return STORED;
            }
            default -> {
                return INVALID_OPTION;
            }
        }
    }

    /** Full details in the required order: ID, Hash, Recipient, Message.
     * @return  */
    public String getMessageDetails() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText;
    }

    /** Returns every message sent while the program is running.
     * @return  */
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent.";
        }
        String output = "";
        for (int i = 0; i < sentMessages.size(); i++) {
            output = output + sentMessages.get(i) + "\n----------------------\n";
        }
        return output;
    }

    /** Returns the total number of messages sent.
     * @return  */
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    /** Clears the counters (used by the unit tests so each test starts fresh). */
    public static void resetMessages() {
        totalMessagesSent = 0;
        sentMessages.clear();
    }

    /**
     * Stores this message in messages.json so it can be sent later.
     * The file holds a JSON array; each message is one JSON object.
     * Existing messages are read first so new ones are added, not overwritten.
     *
     * Code attribution:
     * Uses the JSON-java (org.json) library: JSONObject, JSONArray and toString(indent).
     * Adapted from the examples in:
     *   Leary, S. (2025) JSON-java. GitHub. Available at: https://github.com/stleary/JSON-java
     *   Baeldung (2024) Introduction to JSON-Java. Available at: https://www.baeldung.com/java-org-json
     * File read/write uses java.nio.file.Files (Oracle Java SE documentation).
     */
    public void storeMessage() {
        JSONArray storedArray = readJsonArray(JSON_FILE);

        JSONObject json = new JSONObject();
        json.put("messageID", messageID);
        json.put("messageNumber", messageNumber);
        json.put("messageHash", messageHash);
        json.put("recipient", recipient);
        json.put("message", messageText);

        storedArray.put(json);
        writeJsonArray(JSON_FILE, storedArray);
    }

    /**
     * Reads a JSON file and returns its contents as a JSONArray.
     * Returns an empty array if the file does not exist yet or cannot be read.
     * (Attribution: see storeMessage() above.)
     * @param fileName the JSON file to read
     * @return the messages in the file
     */
    public static JSONArray readJsonArray(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            return new JSONArray();
        }
        try {
            String content = Files.readString(file.toPath());
            if (content.trim().isEmpty()) {
                return new JSONArray();
            }
            return new JSONArray(content);
        } catch (IOException | JSONException e) {
            System.out.println("Could not read " + fileName + ": " + e.getMessage());
            return new JSONArray();
        }
    }

    /**
     * Writes a JSONArray to a file, indented by 4 spaces so it is easy to read.
     * (Attribution: see storeMessage() above.)
     * @param fileName the JSON file to write
     * @param array the messages to save
     */
    public static void writeJsonArray(String fileName, JSONArray array) {
        try {
            Files.writeString(Path.of(fileName), array.toString(4));
        } catch (IOException e) {
            System.out.println("Could not save " + fileName + ": " + e.getMessage());
        }
    }

    // ----- Getters -----
    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
}
