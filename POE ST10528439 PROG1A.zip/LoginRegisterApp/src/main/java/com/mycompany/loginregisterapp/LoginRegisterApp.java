/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginregisterapp;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class LoginRegisterApp {

    public static void main(String[] args) {
      try ( //  Main variables //
                Scanner input = new Scanner(System.in)) {
            String firstName;
            String lastName;
            String username;
            String password;
            String cellPhone;
            boolean loggedIn = false;

           
            Login login = new Login();

            // ----- Registration -----
            System.out.println("");
            System.out.println(" QuickChat - Registration");
            System.out.println("=");

            System.out.print("Enter your first name: ");
            firstName = input.nextLine();
            System.out.print("Enter your last name: ");
            lastName = input.nextLine();
            login.setFirstName(firstName);
            login.setLastName(lastName);

            // Keep asking until each detail is valid
            do {
                System.out.print("Enter a username: ");
                username = input.nextLine();
                System.out.println(login.getUsernameMessage(username));
            } while (!login.checkUserName(username));

            do {
                System.out.print("Enter a password: ");
                password = input.nextLine();
                System.out.println(login.getPasswordMessage(password));
            } while (!login.checkPasswordComplexity(password));

            do {
                System.out.print("Enter your cell phone number (e.g. +27838968976): ");
                cellPhone = input.nextLine();
                System.out.println(login.getCellPhoneMessage(cellPhone));
            } while (!login.checkCellPhoneNumber(cellPhone));

            System.out.println(login.registerUser(username, password, cellPhone));

            // ----- Login -----
            System.out.println();
            System.out.println("=====================================");
            System.out.println("   QuickChat - Login");
            System.out.println("=====================================");

            while (!loggedIn) {
                System.out.print("Username: ");
                String enteredUsername = input.nextLine();
                System.out.print("Password: ");
                String enteredPassword = input.nextLine();

                loggedIn = login.loginUser(enteredUsername, enteredPassword);
                System.out.println(login.returnLoginStatus(loggedIn));
            }

            // ----- Part 2: only reached once the user has logged in -----
            String sender = firstName + " " + lastName + " (" + cellPhone + ")";
            runQuickChat(input, sender);
        }
    }

    /** Part 2 and 3 - the QuickChat menu. Runs until the user chooses Quit.
     * @param input the keyboard scanner
     * @param sender the logged-in user (shown as the sender of stored messages) */
    public static void runQuickChat(Scanner input, String sender) {
        System.out.println();
        System.out.println("Welcome to QuickChat.");

        // Part 3: holds the arrays; picks up messages stored in messages.json on an earlier run
        MessageManager manager = new MessageManager();
        manager.loadStoredMessages();

       
        int numMessages = readNumber(input, "How many messages would you like to send? ");
        while (numMessages < 1) {
            System.out.println("Please enter a number of 1 or more.");
            numMessages = readNumber(input, "How many messages would you like to send? ");
        }
        int messagesEntered = 0; 

        boolean running = true;
        while (running) {                       
            System.out.println();
            System.out.println("Please choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            int option = readNumber(input, "Option: ");

            switch (option) {
                case 1 -> {
                    if (messagesEntered >= numMessages) {
                        System.out.println("You have already entered all " + numMessages + " messages.");
                    } else {
                        // for loop lets the user enter only the set number of messages
                        for (int i = messagesEntered; i < numMessages; i++) {
                            enterMessage(input, i, manager);
                            messagesEntered++;
                        }
                        System.out.println("Total number of messages sent: " + Message.returnTotalMessages());
                    }
                }
                case 2 -> System.out.println(manager.displaySentReport());
                case 3 -> {
                    System.out.println("Goodbye!");
                    running = false;
                }
                case 4 -> storedMessagesMenu(input, manager, sender);
                default -> System.out.println("Invalid option, please enter 1, 2, 3 or 4.");
            }
        }
    }

    /** Part 3 - the Stored Messages sub-menu. */
    private static void storedMessagesMenu(Scanner input, MessageManager manager, String sender) {
        manager.loadStoredMessages(); // read the JSON file into the stored-message array
        boolean inMenu = true;
        while (inMenu) {
            System.out.println();
            System.out.println("----- Stored Messages -----");
            System.out.println("1) Display the sender and recipient of all stored messages");
            System.out.println("2) Display the longest stored message");
            System.out.println("3) Search for a message ID");
            System.out.println("4) Search for all messages for a recipient");
            System.out.println("5) Delete a message using the message hash");
            System.out.println("6) Display a report of all stored messages");
            System.out.println("7) Back to main menu");
            int option = readNumber(input, "Option: ");

            switch (option) {
                case 1 -> System.out.println(manager.displayStoredSenderAndRecipient(sender));
                case 2 -> System.out.println("Longest stored message: " + manager.getLongestStoredMessage());
                case 3 -> {
                    System.out.print("Enter the message ID: ");
                    System.out.println(manager.displayMessageByID(input.nextLine().trim()));
                }
                case 4 -> {
                    System.out.print("Enter the recipient's cell number: ");
                    String[] found = manager.searchByRecipient(input.nextLine().trim());
                    if (found.length == 0) {
                        System.out.println("No messages found for that recipient.");
                    } else {
                        for (String text : found) {
                            System.out.println("\"" + text + "\"");
                        }
                    }
                }
                case 5 -> {
                    System.out.print("Enter the message hash: ");
                    System.out.println(manager.deleteByHash(input.nextLine().trim()));
                }
                case 6 -> System.out.println(manager.displayStoredReport());
                case 7 -> inMenu = false;
                default -> System.out.println("Invalid option, please enter a number from 1 to 7.");
            }
        }
    }

    /** Captures one message, then sends, disregards or stores it and adds it to the arrays. */
    private static void enterMessage(Scanner input, int messageNumber, MessageManager manager) {
        System.out.println();
        System.out.println("----- Message " + (messageNumber + 1) + " -----");

        // Recipient - keep asking until it is valid
        Login checker = new Login(); 
        String recipient;
        boolean validRecipient;
        do {
            System.out.print("Enter the recipient's cell number (e.g. +27718693002): ");
            recipient = input.nextLine().trim();
            validRecipient = checker.checkCellPhoneNumber(recipient);
            if (validRecipient) {
                System.out.println(Message.RECIPIENT_OK);
            } else {
                System.out.println(Message.RECIPIENT_BAD);
            }
        } while (!validRecipient);

        
        String text;
        do {
            System.out.print("Enter your message: ");
            text = input.nextLine();
            if (text.trim().isEmpty()) {
                System.out.println("The message cannot be empty.");
            } else if (text.length() > Message.MAX_LENGTH) {
                System.out.println("Please enter a message of less than 250 characters.");
            }
        } while (text.trim().isEmpty() || text.length() > Message.MAX_LENGTH);

        Message message = new Message(messageNumber, recipient, text);
        System.out.println(message.displayMessageID());

        // Ask what to do with the message
        System.out.println("What would you like to do with this message?");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        int choice = readNumber(input, "Choice: ");
        while (choice < 1 || choice > 3) {
            System.out.println(Message.INVALID_OPTION);
            choice = readNumber(input, "Choice: ");
        }

        System.out.println(message.sentMessage(choice));
        manager.addMessage(message, MessageManager.flagForChoice(choice));

        if (choice == 1) {
            
            System.out.println(message.getMessageDetails());
        } else if (choice == 2) {
            System.out.print("> ");
            String confirm = input.nextLine().trim();
            if (confirm.equals("0")) {
                System.out.println("Message deleted.");
            } else {
                System.out.println("Message disregarded.");
            }
        }
    }

    
    private static int readNumber(Scanner input, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }
}